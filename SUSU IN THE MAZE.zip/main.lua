local gameState = "menu" -- Possible states: 'menu', 'play', 'pause', 'options'
local menuOptions = {"Start Game", "Options", "Quit"}
local endOptions = {"Start Again", "Options", "Quit"}
local pauseOptions = {"Continue", "Options", "Quit"}
local optionsMenu = {"Sound: On", "Back"} -- Sound on/off
local selectedOption = 1
local delayTimer = 0
local delayDuration = 0.2  -- Delay duration between button presses
local soundEnabled = true -- Initial state for sound

-- Background image
local background = love.graphics.newImage('backgrounds/startScreen.png')

local buttonWidth = 200
local buttonHeight = 50
local buttonPadding = 10
local bottomAreaY = 500


-- Sounds
local sounds = {}
sounds.blip = love.audio.newSource('sounds/blip.wav', 'static')
sounds.music = love.audio.newSource('sounds/music.mp3', 'stream')
sounds.music:setLooping(true)
sounds.music:play()

function love.load()
    -- Set up game world, player, camera, etc.
    local windfield = require 'libraries.windfield'
    world = windfield.newWorld(0, 0, true) -- No gravity (0, 0) for top-down games

    local camera = require 'libraries/camera'
    cam = camera()

    -- Import animations
    local anim8 = require 'libraries.anim8'
    love.graphics.setDefaultFilter('nearest', "nearest")  -- Remove blur

    local sti = require 'libraries/sti'
    gameMap = sti('maps/map.lua')
    
    -- Player setup
    player = {}
    player.collider = world:newBSGRectangleCollider(400, 250, 50, 100, 10)
    player.collider:setFixedRotation(true)
    
    player.x = 400
    player.y = 200
    player.speed = 300
    player.spriteSheet = love.graphics.newImage('sprites/player-sheet.png')
    player.grid = anim8.newGrid(12, 18, player.spriteSheet:getWidth(), player.spriteSheet:getHeight())
    
    player.animations = {}
    player.animations.down = anim8.newAnimation(player.grid('1-4', 1), 0.2)
    player.animations.up = anim8.newAnimation(player.grid('1-4', 4), 0.2)
    player.animations.left = anim8.newAnimation(player.grid('1-4', 2), 0.2)
    player.animations.right = anim8.newAnimation(player.grid('1-4', 3), 0.2)
    
    player.anim = player.animations.left

    local mapHeight = gameMap.height * gameMap.tileheight

    doorImage = love.graphics.newImage("sprites/door.png")  -- Load the door image
    local mapHeight = gameMap.height * gameMap.tileheight
    local doorWidth = doorImage:getWidth()
    local doorHeight = doorImage:getHeight()

    -- Place the door at the "gate" (end of the map)
    doorX = 730
    doorY = (mapHeight - doorHeight) + 10  -- Align with the bottom of the map
    
    -- Walls setup
    walls = {}
    if gameMap.layers['walls'] then
        for _, obj in pairs(gameMap.layers['walls'].objects) do
            if obj.width > 0 and obj.height > 0 then
                local wall = world:newRectangleCollider(obj.x, obj.y, obj.width, obj.height)
                wall:setType('static')
                table.insert(walls, wall)
            else
                print("Skipping invalid wall at:", obj.x, obj.y, "Dimensions:", obj.width, obj.height)
            end
        end
    end
end

function love.update(dt)
    if delayTimer > 0 then
        delayTimer = delayTimer - dt
    end

    if gameState == "play" then
        -- Game logic for when the game is playing
        local isMoving = false
        local vx, vy = 0, 0
    
        -- Movement
        if love.keyboard.isDown("right") then
            vx = player.speed
            player.anim = player.animations.right
            isMoving = true
        end
    
        if love.keyboard.isDown("left") then
            vx = -player.speed
            player.anim = player.animations.left
            isMoving = true
        end
    
        if love.keyboard.isDown("up") then
            vy = -player.speed
            player.anim = player.animations.up
            isMoving = true
        end
    
        if love.keyboard.isDown("down") then
            vy = player.speed
            player.anim = player.animations.down
            isMoving = true
        end
    
        -- Update player's position
        player.collider:setLinearVelocity(vx, vy)
    
        -- If the player is not moving, set the animation to a stationary state
        if not isMoving then
            player.anim:gotoFrame(2)
        end

    
        -- Update world and player position
        world:update(dt)
        player.x = player.collider:getX()
        player.y = player.collider:getY()
    
        player.anim:update(dt)
    
        -- Move the camera to follow the player
        cam:lookAt(player.x, player.y)

        -- Camera boundaries
        local w = love.graphics.getWidth()
        local h = love.graphics.getHeight()
        local mapW = gameMap.width * gameMap.tilewidth
        local mapH = gameMap.height * gameMap.tileheight

        if cam.x < w / 2 then cam.x = w / 2 end
        if cam.y < h / 2 then cam.y = h / 2 end
        if cam.x > (mapW - w / 2) then cam.x = (mapW - w / 2) end
        if cam.y > (mapH - h / 2) then cam.y = (mapH - h / 2) end

        local playerBottom = player.y + player.spriteSheet:getHeight()  -- Player's bottom y position
    
        -- Game Over condition: if the player reaches the bottom of the map
        local mapHeight = gameMap.height * gameMap.tileheight
        if player.y >= mapHeight - (player.spriteSheet:getHeight() - 100) then
            gameState = "end"  -- End the game if the player reaches the bottom of the map
        end
    
        -- Handle "escape" to pause
        if love.keyboard.isDown("escape") then
            gameState = "pause" -- Switch to pause state when ESC is pressed
        end
    elseif gameState == "menu" then
        if delayTimer <= 0 then
            if love.keyboard.isDown("left") then
                selectedOption = math.max(1, selectedOption - 1)
                delayTimer = delayDuration
            elseif love.keyboard.isDown("right") then
                selectedOption = math.min(#menuOptions, selectedOption + 1)
                delayTimer = delayDuration
            elseif love.keyboard.isDown("return") then
                if menuOptions[selectedOption] == "Start Game" then
                    gameState = "play"
                elseif menuOptions[selectedOption] == "Options" then
                    gameState = "options"
                elseif menuOptions[selectedOption] == "Quit" then
                    love.event.quit()
                end
                delayTimer = delayDuration
            end
        end
    elseif gameState == "end" then
        if delayTimer <= 0 then
            if love.keyboard.isDown("left") then
                selectedOption = math.max(1, selectedOption - 1)
                delayTimer = delayDuration
            elseif love.keyboard.isDown("right") then
                selectedOption = math.min(#endOptions, selectedOption + 1)
                delayTimer = delayDuration
            elseif love.keyboard.isDown("return") then
                if endOptions[selectedOption] == "Start Again" then
                    gameState = "play"
                elseif endOptions[selectedOption] == "Options" then
                    gameState = "options"
                elseif endOptions[selectedOption] == "Quit" then
                    love.event.quit()
                end
                delayTimer = delayDuration
            end
        end
    elseif gameState == "pause" then
        if delayTimer <= 0 then
            if love.keyboard.isDown("left") then
                selectedOption = math.max(1, selectedOption - 1)
                delayTimer = delayDuration
            elseif love.keyboard.isDown("right") then
                selectedOption = math.min(#pauseOptions, selectedOption + 1)
                delayTimer = delayDuration
            elseif love.keyboard.isDown("return") then
                if pauseOptions[selectedOption] == "Continue" then
                    gameState = "play"
                elseif pauseOptions[selectedOption] == "Options" then
                    gameState = "options"
                elseif pauseOptions[selectedOption] == "Quit" then
                    love.event.quit()
                end
                delayTimer = delayDuration
            end
        end
    elseif gameState == "options" then
        -- Only process input if the delay timer has expired
        if delayTimer <= 0 then
            if love.keyboard.isDown("left") then
                selectedOption = math.max(1, selectedOption - 1)
                delayTimer = delayDuration
            elseif love.keyboard.isDown("right") then
                selectedOption = math.min(#optionsMenu, selectedOption + 1)
                delayTimer = delayDuration
            elseif love.keyboard.isDown("return") then
                if optionsMenu[selectedOption] == "Sound: On" or optionsMenu[selectedOption] == "Sound: Off" then
                    -- Toggle sound state on/off
                    soundEnabled = not soundEnabled
                    if soundEnabled then
                        sounds.music:play()
                        optionsMenu[1] = "Sound: On"  -- Update the option text to "Sound: On"
                    else
                        sounds.music:stop()
                        optionsMenu[1] = "Sound: Off"  -- Update the option text to "Sound: Off"
                    end
                elseif optionsMenu[selectedOption] == "Back" then
                    gameState = "menu"
                end
                delayTimer = delayDuration  -- Reset delay timer after any input
            end
        else
            -- Decrease the delay timer while waiting for next input
            delayTimer = delayTimer - dt
        end
    end
    
end

function love.draw()
    love.graphics.clear(0.1, 0.1, 0.1)  -- Clear screen with a dark background

    -- Draw background image (for all menus)

    -- Calculate startX for positioning the buttons horizontally in the center
    local totalWidth = #menuOptions * (buttonWidth + buttonPadding) - buttonPadding
    local startX = (love.graphics.getWidth() - totalWidth) / 2

    if gameState == "menu" then
        -- Draw menu options
        love.graphics.draw(background, 0, 0, 0, love.graphics.getWidth() / background:getWidth(), love.graphics.getHeight() / background:getHeight())
        love.graphics.printf("Main Menu", 0, 100, love.graphics.getWidth(), "center")
        
        for i, option in ipairs(menuOptions) do
            local buttonX = startX + (i - 1) * (buttonWidth + buttonPadding)
            local buttonY = bottomAreaY

            love.graphics.setColor(0.2, 0.2, 0.2)  -- Dark grey background
            love.graphics.rectangle("fill", buttonX, buttonY, buttonWidth, buttonHeight)

            love.graphics.setColor(1, 1, 1)  -- White text
            love.graphics.printf(option, buttonX, buttonY + 15, buttonWidth, "center")

            -- Highlight selected option
            if selectedOption == i then
                love.graphics.rectangle("line", buttonX, buttonY, buttonWidth, buttonHeight)
            end
        end
    elseif gameState == "end" then
        -- Draw menu options
        love.graphics.draw(background, 0, 0, 0, love.graphics.getWidth() / background:getWidth(), love.graphics.getHeight() / background:getHeight())
        love.graphics.printf("Main Menu", 0, 100, love.graphics.getWidth(), "center")
        
        for i, option in ipairs(endOptions) do
            local buttonX = startX + (i - 1) * (buttonWidth + buttonPadding)
            local buttonY = bottomAreaY

            love.graphics.setColor(0.2, 0.2, 0.2)  -- Dark grey background
            love.graphics.rectangle("fill", buttonX, buttonY, buttonWidth, buttonHeight)

            love.graphics.setColor(1, 1, 1)  -- White text
            love.graphics.printf(option, buttonX, buttonY + 15, buttonWidth, "center")

            -- Highlight selected option
            if selectedOption == i then
                love.graphics.rectangle("line", buttonX, buttonY, buttonWidth, buttonHeight)
            end
        end
    elseif gameState == "pause" then
        -- Draw menu options
        love.graphics.draw(background, 0, 0, 0, love.graphics.getWidth() / background:getWidth(), love.graphics.getHeight() / background:getHeight())
        love.graphics.printf("Pause Menu", 0, 100, love.graphics.getWidth(), "center")
        
        for i, option in ipairs(pauseOptions) do
            local buttonX = startX + (i - 1) * (buttonWidth + buttonPadding)
            local buttonY = bottomAreaY

            love.graphics.setColor(0.2, 0.2, 0.2)  -- Dark grey background
            love.graphics.rectangle("fill", buttonX, buttonY, buttonWidth, buttonHeight)

            love.graphics.setColor(1, 1, 1)  -- White text
            love.graphics.printf(option, buttonX, buttonY + 15, buttonWidth, "center")

            -- Highlight selected option
            if selectedOption == i then
                love.graphics.rectangle("line", buttonX, buttonY, buttonWidth, buttonHeight)
            end
        end
    elseif gameState == "play" then
        cam:attach()
        -- Draw the map layers
        gameMap:drawLayer(gameMap.layers['tree'])
        -- Draw the player
        love.graphics.draw(doorImage, doorX, doorY)
        player.anim:draw(player.spriteSheet, player.x, player.y, nil, 6, nil, 6, 9)
        -- Detach the camera after drawing the game world
        cam:detach()
    elseif gameState == "options" then
        -- Draw options menu
        love.graphics.draw(background, 0, 0, 0, love.graphics.getWidth() / background:getWidth(), love.graphics.getHeight() / background:getHeight())
        love.graphics.printf("Options", 0, 100, love.graphics.getWidth(), "center")
    
        -- Recalculate startX for the options menu (if needed for different button counts)
        local totalWidth = #optionsMenu * (buttonWidth + buttonPadding) - buttonPadding
        local startX = (love.graphics.getWidth() - totalWidth) / 2
    
        for i, option in ipairs(optionsMenu) do
            local buttonX = startX + (i - 1) * (buttonWidth + buttonPadding)
            local buttonY = bottomAreaY
    
            love.graphics.setColor(0.2, 0.2, 0.2)  -- Dark grey background
            love.graphics.rectangle("fill", buttonX, buttonY, buttonWidth, buttonHeight)
    
            love.graphics.setColor(1, 1, 1)  -- White text
            love.graphics.printf(option, buttonX, buttonY + 15, buttonWidth, "center")
    
            -- Highlight selected option
            if selectedOption == i then
                love.graphics.rectangle("line", buttonX, buttonY, buttonWidth, buttonHeight)
            end
        end
    end
end